import React from 'react'
import { IoMdHome } from "react-icons/io";
import { IoMdArrowDropright } from "react-icons/io";
import { IoSchool } from "react-icons/io5";
import { MdLibraryAddCheck } from "react-icons/md";
import { SiGoogleforms } from "react-icons/si";
import { PiBooksFill } from "react-icons/pi";
import { IoPersonAdd } from "react-icons/io5";
import { LuCalendarDays } from "react-icons/lu";
import { MdOutlinePowerSettingsNew } from "react-icons/md";
import { FaGift } from "react-icons/fa6";
import Image from 'next/image'
import Link from 'next/link';

export default function slidebar() {
  return (
    <>
      <div className="sidebar">
        <div className="sidebar_img">
          <Image
            className='logo_siderbar_desk'
            src="/assets/image/Logo1.png"
            width={200}
            height={60}
            alt="Logo"
            priority
          />
          <Image
            className='logo_siderbar_mob'
            src="/assets/image/fav.png"
            width={70}
            height={70}
            alt="Picture of the author"
          />
        </div>
        <div className="sidebar_item">
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/#"><IoMdHome /><span>Dashboard</span></Link>
            </div>
            <div className="sidebar_item_02">
              <a href="#"><IoMdArrowDropright /></a>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/attendance"><MdLibraryAddCheck /><span>Attendance</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/leaves"><FaGift /><span>Leaves</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/signup"><MdOutlinePowerSettingsNew /><span>Logout</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/manager"><IoPersonAdd /><span>Manager</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/student"><IoSchool /><span>Students</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/manager_attendence"><MdLibraryAddCheck /><span>Attendance</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/manager_leaves"><FaGift /><span>Leaves</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/manager_holiday"><LuCalendarDays /><span>Holidays</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/signup"><MdOutlinePowerSettingsNew /><span>Logout</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/teacher"><IoSchool /><span>Teachers</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/course"><PiBooksFill /><span>Course</span></Link>
            </div>
          </div>
          <div className="sidebar_item_wr">
            <div className="sidebar_item_01">
              <Link href="/registration"><SiGoogleforms /><span>Registration</span></Link>
            </div>
          </div>

        </div>
        <div className="sidebar_end">

          <p>Made with ❤︎ by Vatsalya</p>
        </div>
      </div>
    </>
  )
}

